#!/bin/bash
#####################################################################################################################
# Description : This script installs all the necessary files (libraries, QT's UI and Resourse files) to TheSkyX dir. 
# Written by  : Jan Soldan (astrosoft@email.cz)
# Version     : 1.01
# Date        : 8/2017
#####################################################################################################################

# remove libQHYCCDX2* files if exists
rm -rf ../../Resources/Common/PlugIns/CameraPlugIns/libQHYCCDX2* 
 
# copy libQHYCCDX2StaticPlugin.so & links
cp -d ../CameraPlugIns/libQHYCCDX2StaticPlugin.so* ../../Resources/Common/PlugIns/CameraPlugIns

# remove cameralist QHYCCD* files
rm -rf ../../Resources/Common/Miscellaneous\ Files/cameralist\ QHYCCD* 

# copy Miscellaneous files
cp ../MiscellaneousFiles/cameralist\ QHYCCD_STATIC.txt ../../Resources/Common/Miscellaneous\ Files

# copy QTCCD.ui
cp ../CameraPlugIns/QHYCCD.ui ../../Resources/Common/PlugIns/CameraPlugIns
