#!/bin/bash
#####################################################################################################################
# Description : This script installs all the necessary files (libraries, QT's UI and Resourse files) to TheSkyX dir. 
# Written by  : Jan Soldan (astrosoft@email.cz)
# Version     : 1.00
# Date        : 6/2017
#####################################################################################################################

# 1. copy libQHYCCDX2Plugin.so & links
cp -d ../CameraPlugIns/libQHYCCDX2Plugin.so* ../../Resources/Common/PlugInsARM32/CameraPlugIns

# 2. copy QT.ui
cp ../CameraPlugIns/QHYCCD.ui ../../Resources/Common/PlugInsARM32/CameraPlugIns

# 3. copy Miscellaneous files
cp ../MiscellaneousFiles/* ../../Resources/Common/Miscellaneous\ Files
