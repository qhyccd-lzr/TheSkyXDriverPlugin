#!/bin/bash
#####################################################################################################################
# Description : This script installs all the necessary files (libraries, firmwares, include) on Mac OSX machine. 
# Written by  : Jan Soldan (astrosoft@email.cz)
# Version     : 1.00
# Date        : 9/2017
#####################################################################################################################

# 1. LIBUSB
rm -rf /usr/local/lib/libusb-1.0* 
cp -R -P -p ../libusb/* /usr/local/lib

# 2. FIRMWARE
mkdir -p /usr/local/lib/qhy/firmware
cp ../firmware/* /usr/local/lib/qhy/firmware

# 3. LIBQHYX2PLUGIN
rm -rf ../../Resources/Common/PlugIns/CameraPlugIns/libQHYCCDX2* 
cp -R -P -p ../CameraPlugIns/libQHYCCDX2Plugin.* ../../Resources/Common/PlugIns/CameraPlugIns

# QTCCD.ui
cp ../CameraPlugIns/QHYCCD.ui ../../Resources/Common/PlugIns/CameraPlugIns

# CAMERALISTQHYCCD
rm -rf ../../Resources/Common/Miscellaneous\ Files/cameralist\ QHYCCD* 
cp ../MiscellaneousFiles/cameralist\ QHYCCD.txt ../../Resources/Common/Miscellaneous\ Files

