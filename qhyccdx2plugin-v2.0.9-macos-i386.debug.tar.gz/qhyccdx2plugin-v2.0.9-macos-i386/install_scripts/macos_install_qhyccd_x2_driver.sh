#!/bin/bash
#####################################################################################################################
# Description : This script installs all the necessary files (libraries, firmwares, include) on Mac OSX machine. 
# Written by  : Jan Soldan (astrosoft@email.cz)
# Version     : 1.01
# Date        : 11/2017
#####################################################################################################################

# install firmware
mkdir -p /usr/local/lib/qhy/firmware
cp ../firmware/* /usr/local/lib/qhy/firmware

# install LIBQHYX2PLUGIN
rm -rf ../../Resources/Common/PlugIns/CameraPlugIns/libQHYCCDX2* 
cp -R -P -p ../CameraPlugIns/libQHYCCDX2Plugin.* ../../Resources/Common/PlugIns/CameraPlugIns

# install QTCCD.ui
cp ../CameraPlugIns/QHYCCD.ui ../../Resources/Common/PlugIns/CameraPlugIns

# install cameralist QHYCCD.txt
rm -rf ../../Resources/Common/Miscellaneous\ Files/cameralist\ QHYCCD* 
cp ../MiscellaneousFiles/cameralist\ QHYCCD.txt ../../Resources/Common/Miscellaneous\ Files
